import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trash-bar',
  templateUrl: './trash-bar.component.html',
  styleUrls: ['./trash-bar.component.scss']
})
export class TrashBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
