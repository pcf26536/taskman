import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrashBarComponent } from './trash-bar.component';

describe('TrashBarComponent', () => {
  let component: TrashBarComponent;
  let fixture: ComponentFixture<TrashBarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TrashBarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TrashBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
